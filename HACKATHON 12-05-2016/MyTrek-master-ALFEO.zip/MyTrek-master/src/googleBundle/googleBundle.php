<?php

namespace googleBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class googleBundle extends Bundle
{
}
