<?php

namespace dojoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class dojoBundle extends Bundle
{
}
